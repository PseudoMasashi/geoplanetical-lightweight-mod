/* Optional preparation controls. This module changes no economic figures. */
(() => {
 'use strict';
 const root=window,GiB=1024**3,owners=new Map(),closedWorkers=new WeakSet();let desired=true,evenPacing=true,worker=null,attached=null,lastEnabled=null,lastPacing=null,latest=null,reason='',serial=0,memoryLatched=false;
 try{desired=root.localStorage.getItem('geo.month-ahead.enabled')!=='off';}catch{}
 try{evenPacing=root.localStorage.getItem('geo.month-ahead.pacing')!=='off';}catch{}
 function memory(){try{const m=root.desktop?.lightweightMemory?.();return m&&Number.isFinite(m.freeBytes)&&Number.isFinite(m.totalBytes)?m:null;}catch{return null;}}
 function send(enabled){if(!worker||enabled===lastEnabled&&evenPacing===lastPacing)return;lastEnabled=enabled;lastPacing=evenPacing;worker.postMessage({protocolVersion:2,type:'request',requestId:Number.MAX_SAFE_INTEGER-(++serial),sessionEpoch:0,command:'lookahead.configure',payload:{enabled,smoothCalendar:evenPacing}});}
 function resources(initial=false){
  const m=memory();let ok=!!m&&m.totalBytes>=12*GiB;
  if(desired&&lastEnabled===true&&(!ok||m.freeBytes<1.25*GiB))memoryLatched=true;
  const loaded=attached?.getState?.()==='game'&&attached?.getSession?.()?.status?.ready,restartGiB=loaded?4:7;
  if(ok)ok=m.freeBytes>=(initial||lastEnabled!==true?restartGiB:1.25)*GiB;
  reason=!desired?'Off':memoryLatched?'Paused because memory was low. Select Retry when enough memory is free.':!ok?'Paused to leave enough memory for the game':'';
  send(desired&&ok&&!memoryLatched);refresh();
 }
 function setEnabled(value){desired=!!value;memoryLatched=false;try{root.localStorage.setItem('geo.month-ahead.enabled',desired?'on':'off');}catch{}resources(true);}
 function attachWorker(value){
  worker=value;lastEnabled=null;latest=null;memoryLatched=false;
  value.addEventListener('message',e=>{const m=e.data;if(m?.type==='event'&&m.eventId==='lookahead.status'){latest=m.payload;refresh();}else if(m?.type==='event'&&m.eventId==='lookahead.transport'){const control=m.payload;if(control?.type==='geo.remote.open'){if(closedWorkers.has(value))return;owners.set(control.id,value);root.desktop?.monthAhead?.open(control.id);}else if(control?.type==='geo.remote.close'){owners.delete(control.id);root.desktop?.monthAhead?.close(control.id);}}});
  const terminate=value.terminate.bind(value);value.terminate=()=>{closedWorkers.add(value);for(const[id,owner]of owners)if(owner===value){owners.delete(id);root.desktop?.monthAhead?.close(id);}if(worker===value){worker=null;lastEnabled=null;latest=null;refresh();}return terminate();};
  resources(true);
 }
 root.addEventListener('message',e=>{if(e.source!==root||e.data?.type!=='geo.month.port'||e.ports.length!==1)return;const owner=owners.get(e.data.id);if(owner)owner.postMessage({type:'geo.remote.port',id:e.data.id,port:e.ports[0]},[e.ports[0]]);else e.ports[0].close();});
 root.desktop?.monthAhead?.onFailure(info=>{owners.get(info.id)?.postMessage({type:'geo.remote.failed',id:info.id,message:info.message});});
 function refresh(){
  const button=document.getElementById('geo-month-ahead-toggle');if(button){button.textContent=desired&&memoryLatched?'Retry':desired?'On':'Off';button.setAttribute('aria-pressed',String(desired&&!memoryLatched));}
  const pacing=document.getElementById('geo-month-ahead-pacing');if(pacing){pacing.textContent=evenPacing?'On':'Off';pacing.setAttribute('aria-pressed',String(evenPacing));}
  const label=document.getElementById('geo-month-ahead-state');if(!label)return;
  const states={booting:'Loading background preparation',capturing:'Preparing a fresh copy of the current world',calculating:'Preparing next month',waiting:'Finishing next month in the background',ready:'Next month prepared',verifying:'Checking the prepared result',armed:'Next month prepared',blocked:'Waiting for a player decision',failed:'Using normal calculations'};
  label.textContent=reason||states[latest?.state]||'Preparation starts when a campaign is loaded';
  const note=document.getElementById('geo-month-ahead-note');if(note){note.hidden=!!reason||attached?.getState?.()!=='game'||!latest?.waitingAtBoundary&&!['verifying','capturing'].includes(latest?.state);note.textContent=latest?.state==='verifying'?"Checking next month's figures. Previous figures remain available.":latest?.state==='capturing'?'Preparing a fresh copy of the current world.':'Finishing month-end in the background. Previous figures remain available.';}
 }
 function attach(options){
  attached=options;const pane=document.getElementById('pane-graphics');if(!pane||document.getElementById('geo-month-ahead-control'))return;
  const row=document.createElement('div');row.className='set-row';row.id='geo-month-ahead-control';
  const label=document.createElement('div');label.className='set-label';
  const title=document.createElement('span');title.className='set-name';title.textContent='Prepare month-end while playing';
  const desc=document.createElement('span');desc.className='set-desc';desc.textContent='Run the full original calculations in advance. Uses more memory and caps rendering at 30 FPS. Changes to the world can require recalculation.';
  const state=document.createElement('span');state.className='set-desc';state.id='geo-month-ahead-state';label.append(title,desc,state);
  const box=document.createElement('div');box.className='set-ctrl';const button=document.createElement('button');button.type='button';button.className='k';button.id='geo-month-ahead-toggle';button.setAttribute('aria-label','Prepare month-end while playing');button.addEventListener('click',()=>setEnabled(memoryLatched&&desired?true:!desired));box.append(button);row.append(label,box);pane.prepend(row);refresh();
  const pacingRow=document.createElement('div');pacingRow.className='set-row';const pacingLabel=document.createElement('div');pacingLabel.className='set-label';const pacingTitle=document.createElement('span');pacingTitle.className='set-name';pacingTitle.textContent='Even month pacing';const pacingDesc=document.createElement('span');pacingDesc.className='set-desc';pacingDesc.textContent='Spread calendar progress more evenly while the next month is prepared. Off keeps the original day pacing; unfinished calculations can still pause at month-end.';pacingLabel.append(pacingTitle,pacingDesc);const pacingBox=document.createElement('div');pacingBox.className='set-ctrl';const pacingButton=document.createElement('button');pacingButton.type='button';pacingButton.className='k';pacingButton.id='geo-month-ahead-pacing';pacingButton.setAttribute('aria-label','Even month pacing');pacingButton.addEventListener('click',()=>{evenPacing=!evenPacing;try{root.localStorage.setItem('geo.month-ahead.pacing',evenPacing?'on':'off');}catch{}resources();});pacingBox.append(pacingButton);pacingRow.append(pacingLabel,pacingBox);row.after(pacingRow);refresh();
  const note=document.createElement('div');note.id='geo-month-ahead-note';note.hidden=true;note.setAttribute('role','status');Object.assign(note.style,{position:'fixed',top:'62px',left:'50%',transform:'translateX(-50%)',zIndex:'7000',maxWidth:'80vw',padding:'7px 12px',fontSize:'12px',color:'#e8e9eb',background:'rgba(20,24,30,.94)',border:'1px solid rgba(200,205,215,.25)',borderRadius:'4px',pointerEvents:'none'});document.body.append(note);refresh();
 }
 root.__geoMonthAhead={attach,attachWorker,setEnabled,snapshot:()=>({desired,evenPacing,enabled:lastEnabled,status:latest,reason,memory:memory()})};
 root.setInterval(()=>{if(worker)resources();},1000);
})();
