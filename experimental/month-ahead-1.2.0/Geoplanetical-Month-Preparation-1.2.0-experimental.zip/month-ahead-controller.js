(function(root){
 'use strict';
 class MonthAheadController{
  constructor({createEndpoint,now=()=>performance.now(),yieldControl=result=>result?.waiting?new Promise(r=>setTimeout(r,2)):globalThis.scheduler?.yield?.()||Promise.resolve(),enabled=true,smoothCalendar=true,estimatedMonthMs=95000,maxRawBytes=768*1024*1024,recycleWorkers=true,onStatus=()=>{},onPromoteEvents=()=>{}}){
   Object.assign(this,{createEndpoint,now,yieldControl,enabled,smoothCalendar,estimatedMonthMs,maxRawBytes,recycleWorkers,onStatus,onPromoteEvents});
   this.authority=createEndpoint('authority');this.prediction=null;this.bootstrapping=null;this.startupSeed=null;this.generation=0;this.sequence=0;this.subscriptions=new Map();this.latest=null;this.lastRevision=0;this.closed=false;this.lastFailure=null;this.retryBlocked=false;
   this.metrics={starts:0,recycledWorkers:0,cancellations:0,promotions:0,misses:0,mismatches:0,errors:0,backgroundSteps:0,backgroundDays:0,prefixCheckMs:0,snapshotExportMs:0,snapshotExportMaxMs:0};
   this.recycledMonthMs=null;this.estimatedRolloverMs=45000;this.estimatedVerifyMs=10000;this.estimatedBootMs=45000;this.measuredMonth=false;this.measuredRollover=false;
  }
  status(){const p=this.prediction;return {enabled:this.enabled,state:p?.state||(this.retryBlocked?'failed':'idle'),targetDay:p?.targetDay??null,phase:p?.progress||null,estimatedWorkMs:p?.estimatedMs??null,elapsedPreparationMs:p?this.now()-p.startedAt:0,estimatedVerificationMs:this.estimatedVerifyMs,waitingAtBoundary:!!this.latest?.gate?.hit&&(!p?.ready||!p?.verified),clockScale:this.clockScale(),lastFailure:this.lastFailure,...this.metrics};}
  announce(){this.onStatus(this.status());}
  async cancel(reason){
   this.generation++;const p=this.prediction;this.prediction=null;
   const boot=this.bootstrapping;this.bootstrapping=null;
   if(boot){boot.cancelled=true;boot.reason=reason;this.metrics.cancellations++;await boot.endpoint.terminate();}
   if(p){p.cancelled=true;p.reason=reason;this.metrics.cancellations++;await p.endpoint?.terminate();if(p.armed||p.arming)await this.authority.call('lookahead.release');}
   this.announce();
  }
  isCurrent(p){return !this.closed&&!p.cancelled&&this.prediction===p&&p.generation===this.generation;}
  clockScale(){
   const p=this.prediction,f=this.latest;if(!this.smoothCalendar||!p||p.ready||!f||['failed','blocked'].includes(p.state))return 1;
   const rate=[0,.5,1,1.5][f.clock.speedIdx]||0;if(!rate)return 1;
   const remainingDays=p.targetDay-1-f.day;if(remainingDays<=0)return 1;
   const remainingSeconds=Math.max(5,(p.estimatedMs-this.estimatedVerifyMs-(this.now()-p.startedAt))/1000);
   return Math.max(.05,Math.min(1,remainingDays/(rate*remainingSeconds)));
  }
  start(bootstrap=null){
   if(!this.enabled||this.closed||this.retryBlocked||this.prediction||!this.latest||this.latest.pending||this.latest.transportPending||!this.latest.outcomeActive||this.latest.blocked.length){bootstrap?.endpoint.terminate().catch(()=>{});return;}
   if(this.startupSeed&&this.startupSeed.targetDay!==this.latest.nextMonthDay)this.startupSeed=null;
   if(!bootstrap&&this.startupSeed){
    const seed=this.startupSeed,savePayload=structuredClone(seed.payload),endpoint=this.createEndpoint('shadow');
    const promise=endpoint.call('session.boot',{playerKey:seed.playerKey,savePayload,viewSubscriptions:[]},savePayload.parts.map(p=>p.bytes));promise.catch(()=>{});bootstrap={endpoint,promise,deferred:true};
   }
   const p={generation:this.generation,id:String(++this.sequence),startedAt:this.now(),targetDay:this.latest.nextMonthDay,state:bootstrap?'booting':'capturing',cancelled:false,ready:false,armed:false,prefix:null,bootstrap,endpoint:bootstrap?.endpoint};
   p.estimatedMs=bootstrap?.recycled?(this.recycledMonthMs??this.estimatedMonthMs+this.estimatedRolloverMs):this.estimatedMonthMs+(bootstrap?.deferred?this.estimatedBootMs:!bootstrap?this.estimatedBootMs+15000:0);
   this.prediction=p;this.metrics.starts++;this.announce();
   p.promise=this.runPrediction(p).catch(async e=>{
    if(this.isCurrent(p)){p.state='failed';p.error=String(e.message||e);this.lastFailure={reason:'prediction-failed',message:p.error,targetDay:p.targetDay};this.metrics.errors++;this.retryBlocked=true;this.announce();await this.cancel('prediction-failed');}
   });
  }
  async runPrediction(p){
   if(p.bootstrap){
    const bootAt=this.now();
    await p.bootstrap.promise;
    if(p.bootstrap.deferred)this.estimatedBootMs=Math.max(1,this.now()-bootAt);
    if(!this.isCurrent(p)){await p.endpoint.terminate();return;}
    const facts=await p.endpoint.call('lookahead.facts');if(!p.bootstrap.recycled)p.targetDay=facts.nextMonthDay;
   }else{
   const exportStart=this.now();let capture;
   try{capture=await this.authority.call('lookahead.export',{maxRawBytes:this.maxRawBytes});}
   finally{const elapsed=this.now()-exportStart;this.metrics.snapshotExportMs+=elapsed;this.metrics.snapshotExportMaxMs=Math.max(this.metrics.snapshotExportMaxMs,elapsed);}
   if(!this.isCurrent(p))return;
   if(capture.rawBytes>this.maxRawBytes)throw Error('lookahead:snapshot-budget');
   // A queued day may have committed before capture got its stable boundary.
   p.targetDay=capture.facts.nextMonthDay;
   p.endpoint=this.createEndpoint('shadow');p.state='booting';this.announce();
   await p.endpoint.call('session.boot',{playerKey:capture.facts.playerKey||capture.payload.meta.playerKey,savePayload:capture.payload,viewSubscriptions:[]},capture.payload.parts.map(p=>p.bytes));
   }
   if(!this.isCurrent(p)){await p.endpoint.terminate();return;}
   await p.endpoint.call('lookahead.configureShadow',{targetDay:p.targetDay});
   p.workStartedAt=this.now();
   p.state='calculating';this.announce();
   for(;;){
    if(!this.isCurrent(p))return;
    const result=await p.endpoint.call('lookahead.step',{budgetMs:16});
    if(!this.isCurrent(p))return;
    this.metrics.backgroundSteps+=result.steps||0;this.metrics.backgroundDays+=result.advanced||0;p.progress=result;
    if(result.needsPrefix){p.prefix=await p.endpoint.call('lookahead.capturePrefix');p.rolloverStartedAt=this.now();}
    if(result.ready){
     if(!p.prefix)throw Error('lookahead:missing-prefix');
     p.ready=true;p.state='ready';p.elapsedMs=this.now()-p.startedAt;
     if(p.bootstrap?.recycled)this.recycledMonthMs=this.recycledMonthMs===null?p.elapsedMs:.7*this.recycledMonthMs+.3*p.elapsedMs;
     else{const measured=this.now()-p.workStartedAt;this.estimatedMonthMs=this.measuredMonth ? .7*this.estimatedMonthMs+.3*measured : measured;this.measuredMonth=true;}
     if(Number.isFinite(p.rolloverStartedAt)){const measured=this.now()-p.rolloverStartedAt;this.estimatedRolloverMs=this.measuredRollover ? .7*this.estimatedRolloverMs+.3*measured : measured;this.measuredRollover=true;}
     this.announce();return;
    }
    if(!result.outcomeActive||result.blocked?.length){p.state='blocked';this.announce();return;}
    await this.yieldControl(result);
   }
  }
  async maybeArm(){
   const p=this.prediction,f=this.latest;
   if(!p||!f||f.pending||f.transportPending||f.blocked.length||!f.outcomeActive||f.day!==p.targetDay-1||!this.isCurrent(p))return;
   if(!p.armed){
    p.arming=true;
    try{await this.authority.call('lookahead.arm',{targetDay:p.targetDay,generation:p.id});}
    catch(e){if(this.isCurrent(p)){this.metrics.errors++;this.retryBlocked=true;this.lastFailure={reason:'verification-failed',message:String(e.message||e),targetDay:p.targetDay};await this.cancel('verification-failed');}return;}
    p.arming=false;if(!this.isCurrent(p)){await this.authority.call('lookahead.release');return;}p.armed=true;p.dirty=true;p.state='waiting';this.announce();
   }
   // Hold the original world before it starts an expensive duplicate closure.
   // The hold grants no permission to promote: exact verification is still
   // mandatory once the prepared prefix arrives.
   if(!p.prefix||p.verified&&!p.dirty)return;
   p.state='verifying';this.announce();const t=this.now();
   try{
   const actual=await this.authority.call('lookahead.witness');this.metrics.prefixCheckMs+=this.now()-t;
   if(!this.isCurrent(p))return;
   if(JSON.stringify(actual)!==JSON.stringify(p.prefix)){
    this.metrics.mismatches++;this.retryBlocked=true;this.lastFailure={reason:'prefix-mismatch',actual,expected:p.prefix};await this.cancel('prefix-mismatch');return;
   }
   p.dirty=false;p.verified=true;this.estimatedVerifyMs=.7*this.estimatedVerifyMs+.3*(this.now()-t);
   p.state=p.ready?'armed':'waiting';this.announce();
   }catch(e){
    if(this.isCurrent(p)){this.metrics.errors++;this.retryBlocked=true;this.lastFailure={reason:'verification-failed',message:String(e.message||e),targetDay:p.targetDay};await this.cancel('verification-failed');}
   }
  }
  async pulse(payload){
   await this.maybeArm();
   let response=await this.authority.call('lookahead.pacedPulse',{...payload,scale:this.clockScale()});
   this.latest=response.facts;this.lastRevision=Math.max(this.lastRevision,response.status.commitRevision||0);
   const p=this.prediction;
   if(response.facts.gate?.hit){
    if(p?.armed&&(!p.ready||!p.verified)&&this.isCurrent(p)&&response.facts.gate.generation===p.id){if(!p.gateReported){p.gateReported=true;p.state='waiting';this.announce();}return response.status;}
    if(p?.armed&&p.ready&&p.verified&&this.isCurrent(p)&&response.facts.gate.generation===p.id){
     // Keep the original authority intact until the fully computed worker has
     // accepted the exact verified prefix and all current view parameters.
     try{
      const promoted=await p.endpoint.call('lookahead.promote',{prefixDay:p.prefix.day,clock:response.facts.clock,commitRevision:this.lastRevision,subscriptions:[...this.subscriptions].map(([viewId,params])=>({viewId,params}))});
      if(!this.isCurrent(p))throw Error('lookahead:promotion-cancelled');
      const old=this.authority;this.authority=p.endpoint;p.endpoint=null;this.prediction=null;this.startupSeed=null;this.generation++;
      this.metrics.promotions++;this.latest=promoted.facts;this.lastRevision=promoted.status.commitRevision;this.announce();
      this.onPromoteEvents(promoted.events||[],this.lastRevision);
      // The previous authority is still an exact, independently verified
      // prefix. Let it finish the original rollover and prepare the following
      // month, instead of serializing and rebuilding a third copy of the world.
      if(this.recycleWorkers){this.metrics.recycledWorkers++;this.start({endpoint:old,recycled:true,promise:Promise.resolve()});}
      else{await old.terminate();this.start();}
      return promoted.status;
     }catch(e){this.metrics.errors++;this.lastFailure={reason:'promotion-failed',message:String(e.message||e),targetDay:p.targetDay};await this.cancel('promotion-failed');}
    }
    await this.authority.call('lookahead.release');
    response=await this.authority.call('lookahead.pacedPulse',{dtSeconds:0,scale:1});this.latest=response.facts;
   }
   const current=this.prediction;
   if(current&&(this.latest.day>=current.targetDay||this.latest.jobTargetDay===current.targetDay&&!this.latest.gate?.hit)){
    this.metrics.misses++;await this.cancel('boundary-not-ready');
   }
   await this.maybeArm();
   if(!this.latest.pending)this.start();
   return response.status;
  }
  async dispatch(command,payload={}){
   if(this.closed&&command!=='session.shutdown')throw Error('lookahead:closed');
   if(command==='session.boot'){
    await this.cancel('new-session');this.startupSeed=null;this.retryBlocked=false;this.subscriptions.clear();const bootGeneration=this.generation;let bootstrap=null;
    if(payload.savePayload)this.startupSeed={payload:structuredClone(payload.savePayload),playerKey:payload.playerKey,targetDay:null};
    if(this.enabled&&payload.savePayload){
     // Both worlds restore the same existing save. This overlaps their normal
     // load work and avoids serializing the freshly restored authority again.
     const savePayload=structuredClone(this.startupSeed.payload),endpoint=this.createEndpoint('shadow');
     const promise=endpoint.call('session.boot',{...payload,savePayload,viewSubscriptions:[]},savePayload.parts.map(p=>p.bytes));promise.catch(()=>{});bootstrap={endpoint,promise};this.bootstrapping=bootstrap;
    }
    let result;try{result=await this.authority.call(command,payload,payload.savePayload?.parts?.map(p=>p.bytes)||[]);}catch(e){this.startupSeed=null;if(this.bootstrapping===bootstrap)this.bootstrapping=null;await bootstrap?.endpoint.terminate();throw e;}
    if(this.bootstrapping===bootstrap)this.bootstrapping=null;
    this.latest=await this.authority.call('lookahead.facts');this.lastRevision=result.status.commitRevision||0;
    if(this.startupSeed)this.startupSeed.targetDay=this.latest.nextMonthDay;
    for(const v of payload.viewSubscriptions||[])this.subscriptions.set(v.viewId,structuredClone(v.params||{}));
    if(this.closed||this.generation!==bootGeneration)await bootstrap?.endpoint.terminate();else this.start(bootstrap);return result;
   }
   if(command==='clock.pulse')return this.pulse(payload);
   if(command==='view.subscribe'){
    const p=this.prediction;if(p?.armed)p.dirty=true;
    if(payload.active===false)this.subscriptions.delete(payload.viewId);else this.subscriptions.set(payload.viewId,structuredClone(payload.params||{}));
    return this.authority.call(command,payload);
   }
   if(command==='view.snapshot'||command==='save.snapshot'){
    const p=this.prediction;if(p?.armed)p.dirty=true;
    return this.authority.call(command,payload);
   }
   if(command==='clock.setSpeed'){
    if(this.prediction?.armed)this.prediction.dirty=true;
    const result=await this.authority.call(command,payload);this.latest=await this.authority.call('lookahead.facts');this.start();return result;
   }
   if(command==='session.shutdown'){
    this.closed=true;this.startupSeed=null;await this.cancel('shutdown');return this.authority.call(command,payload);
   }
   // Every mutating or unclassified command invalidates the entire prediction.
   // No player decision is guessed or silently delayed to a later month.
   this.startupSeed=null;await this.cancel('state-changing-command');this.retryBlocked=false;
   const result=await this.authority.call(command,payload);this.latest=await this.authority.call('lookahead.facts');this.start();return result;
  }
 }
 root.GeoMonthAheadController=MonthAheadController;
 if(typeof module!=='undefined')module.exports={MonthAheadController};
})(globalThis);
