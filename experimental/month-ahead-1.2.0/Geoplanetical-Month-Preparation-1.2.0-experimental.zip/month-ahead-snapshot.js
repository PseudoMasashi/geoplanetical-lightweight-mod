/* Read-only in-memory snapshot path. Ordinary game saves retain their codec. */
(function(root){
 'use strict';
 async function rawSnapshot(host,api){
  const sim=host.requireHealthySession();await host.settlePendingDay(sim);host.requireHealthySession();api.resetRepairs();
  const start=performance.now(),finance=api.finance(sim),t1=performance.now(),transport=api.transport(sim),t2=performance.now(),statistics=api.statistics(sim),t3=performance.now();
  if(!finance||!transport||!statistics)throw Error('lookahead:raw-snapshot-parts');
  const manifest=api.manifest(sim,{financeDescriptor:finance.descriptor,transportDescriptor:transport.descriptor,statisticsDescriptor:statistics.descriptor}),t4=performance.now();
  const parts=api.encode(manifest);
  for(const[id,value]of [['finance',finance],['transport',transport],['statistics',statistics]]){
   // These are the original encoder's owned disposable buffers. The ordinary
   // codec path also transfers/detaches them when posting to its deflate pool.
   if(!(value.bytes instanceof ArrayBuffer)||value.bytes.byteLength!==value.rawBytes)throw Error('lookahead:raw-snapshot-buffer');
   parts.push({id,source:'raw',compression:'identity',rawBytes:value.rawBytes,bytes:value.bytes});
  }
  const artifact={parts};api.validate(artifact);const meta=host.buildSaveMeta(sim,manifest),repairs=api.resetRepairs();
  return {artifact,meta,perf:{mode:'raw-lookahead',totalMs:performance.now()-start,financePrepareMs:t1-start,transportPrepareMs:t2-t1,statisticsPrepareMs:t3-t2,manifestCaptureMs:t4-t3,coreEncodeMs:performance.now()-t4},...(repairs?{repairs}:{})};
 }
 root.__geoCaptureRaw=rawSnapshot;if(typeof module!=='undefined')module.exports={rawSnapshot};
})(globalThis);
