/* A private host for one unmodified numerical engine, with no visible game UI. */
(() => {
 'use strict';
 const params=new URL(location.href).searchParams,id=params.get('id'),name=params.get('worker');
 if(!/^world-[a-z0-9-]+$/.test(id||'')||!['simulation-worker.bundle.js','simulation-worker.lookahead.bundle.js','simulation-worker.original.bundle.js'].includes(name))throw Error('Invalid background world');
 const engine=new Worker(name),tracked=new Map(),special=new Set(['session.boot','lookahead.capturePrefix','lookahead.witness','lookahead.promote','save.snapshot']);let port=null;
 function transfers(value){const list=[],seen=new WeakSet();function visit(v){if(!v||typeof v!=='object'||seen.has(v))return;seen.add(v);if(v instanceof ArrayBuffer){list.push(v);return;}if(ArrayBuffer.isView(v)){visit(v.buffer);return;}for(const k of Object.keys(v))visit(v[k]);}visit(value);return list;}
 engine.onmessage=e=>{const m=e.data;port?.postMessage(m,transfers(m));if(m.type==='event'&&m.eventId==='boot.phase'&&m.payload?.index===0&&m.payload?.state==='start')setTimeout(()=>window.__geoWorldMemory?.reclaim(id,'restored'),0);if(m.type==='response'&&tracked.has(m.requestId)){const command=tracked.get(m.requestId);tracked.delete(m.requestId);if(m.ok){const phase=command==='session.boot'?'booted':command==='lookahead.promote'?'commit':'snapshot',cycle=command==='session.boot'?0:m.payload?.day??m.payload?.facts?.day??m.requestId;setTimeout(()=>window.__geoWorldMemory?.reclaim(id,phase,cycle),0);}}};
 engine.onerror=e=>port?.postMessage({type:'replay.fatal',message:e.message||'Background world failed'});
 engine.onmessageerror=()=>port?.postMessage({type:'replay.fatal',message:'Background world message failed'});
 addEventListener('message',e=>{if(e.source!==window||e.data?.type!=='geo.month.port'||e.data.id!==id||e.ports.length!==1)return;if(port){e.ports[0].close();return;}port=e.ports[0];port.onmessage=m=>{if(special.has(m.data?.command))tracked.set(m.data.requestId,m.data.command);engine.postMessage(m.data,transfers(m.data));};port.start();});
})();
