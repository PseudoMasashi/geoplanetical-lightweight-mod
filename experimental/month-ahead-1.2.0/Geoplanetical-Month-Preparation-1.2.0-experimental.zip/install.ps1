param([string]$GameFolder,[string]$Destination,[switch]$CheckOnly,[switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$mod = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'mod.json') -Raw | ConvertFrom-Json
trap {
    Write-Host ('Stopped: '+$_.Exception.Message) -ForegroundColor Yellow
    Write-Host 'Your original game and saves were not changed.'
    if($Destination) { Write-Host ('Any incomplete separate copy is at: '+$Destination) }
    exit 1
}
function Get-Sha256([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Read-Exactly($Stream,[byte[]]$Buffer,[int]$Count) {
    $done = 0
    while($done -lt $Count) {
        $read = $Stream.Read($Buffer,$done,$Count-$done)
        if($read -eq 0) { throw 'The game archive ended unexpectedly.' }
        $done += $read
    }
}
function Get-AsarFiles($Node,[string]$Prefix,$List) {
    foreach($property in $Node.files.PSObject.Properties) {
        $name = if($Prefix) { $Prefix + '/' + $property.Name } else { $property.Name }
        $entry = $property.Value
        if($entry.PSObject.Properties['files']) { Get-AsarFiles $entry $name $List }
        else {
            $oldOffset = if($entry.PSObject.Properties['offset']) { [long]$entry.offset } else { 0 }
            [void]$List.Add([pscustomobject]@{Path=$name;Entry=$entry;OldOffset=$oldOffset})
        }
    }
}
function Set-Integrity($Entry,[byte[]]$Bytes) {
    $blockSize = 4*1024*1024
    $blocks = New-Object 'System.Collections.Generic.List[string]'
    for($start=0;$start -lt $Bytes.Length;$start+=$blockSize) {
        $count = [Math]::Min($blockSize,$Bytes.Length-$start)
        $part = New-Object byte[] $count
        [Array]::Copy($Bytes,$start,$part,0,$count)
        [void]$blocks.Add((Get-Sha256 $part))
    }
    $Entry.size = $Bytes.Length
    $Entry.integrity = [pscustomobject]@{algorithm='SHA256';hash=(Get-Sha256 $Bytes);blockSize=$blockSize;blocks=@($blocks.ToArray())}
}
function Copy-Runtime([string]$From,[string]$To) {
    [void][IO.Directory]::CreateDirectory($To)
    foreach($item in Get-ChildItem -LiteralPath $From -Force) {
        if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked installation files are not supported.' }
        $next = Join-Path $To $item.Name
        if($item.PSIsContainer) { Copy-Runtime $item.FullName $next }
        elseif($item.FullName -ne $script:sourceArchive) { [IO.File]::Copy($item.FullName,$next,$false) }
    }
}
foreach($file in $mod.fileSha256.PSObject.Properties) {
    $modFile = Join-Path $PSScriptRoot $file.Name
    if((Get-Sha256 ([IO.File]::ReadAllBytes($modFile))) -ne $file.Value) { throw ('A mod file failed verification: '+$file.Name) }
}
if(-not $GameFolder) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Select your ORIGINAL game folder containing Geoplanetical.exe'
    $dialog.ShowNewFolderButton = $false
    if($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { Write-Host 'Cancelled.'; exit 0 }
    $GameFolder = $dialog.SelectedPath
}
$GameFolder = [IO.Path]::GetFullPath($GameFolder).TrimEnd('\','/')
$sourceArchive = Join-Path $GameFolder 'resources\app.asar'
$sourceExe = Join-Path $GameFolder 'Geoplanetical.exe'
if(-not (Test-Path -LiteralPath $sourceExe) -or -not (Test-Path -LiteralPath $sourceArchive)) { throw 'Choose the folder containing Geoplanetical.exe and its resources folder.' }
$source = [IO.File]::Open($sourceArchive,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
try {
    $prefix = New-Object byte[] 16
    Read-Exactly $source $prefix 16
    $oldDataOffset = [long]8 + [BitConverter]::ToUInt32($prefix,4)
    $jsonBytes = New-Object byte[] ([BitConverter]::ToUInt32($prefix,12))
    Read-Exactly $source $jsonBytes $jsonBytes.Length
    $oldHeaderHash = Get-Sha256 $jsonBytes
    $header = $utf8.GetString($jsonBytes) | ConvertFrom-Json
    $all = New-Object 'System.Collections.Generic.List[object]'
    Get-AsarFiles $header '' $all
    $replacements = New-Object 'System.Collections.Generic.Dictionary[string,byte[]]' ([StringComparer]::Ordinal)
    foreach($target in $mod.targets) {
        $match = @($all | Where-Object Path -CEQ $target.path)
        if($match.Count -ne 1) { throw ('Expected game file missing: '+$target.path) }
        [void]$source.Seek(($oldDataOffset+$match[0].OldOffset),[IO.SeekOrigin]::Begin)
        $originalBytes = New-Object byte[] ([int]$match[0].Entry.size)
        Read-Exactly $source $originalBytes $originalBytes.Length
        if((Get-Sha256 $originalBytes) -ne $target.sourceSha256) { throw 'This game build is not supported, or it is already modified. Select the original game folder.' }
        $text = $utf8.GetString($originalBytes)
        foreach($patch in $target.patches) {
            $at = $text.IndexOf([string]$patch.find,[StringComparison]::Ordinal)
            if($at -lt 0 -or $at -ne $text.LastIndexOf([string]$patch.find,[StringComparison]::Ordinal)) { throw ('An integration point was not unique: '+$target.path) }
            $text = $text.Replace([string]$patch.find,[string]$patch.replace)
        }
        $modPrefix = ''
        foreach($file in $target.prefixFiles) { $modPrefix += $utf8.GetString([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $file)))+[char]10 }
        $bytes = $utf8.GetBytes($modPrefix+$text)
        if((Get-Sha256 $bytes) -ne $target.resultSha256) { throw ('Patched file failed verification: '+$target.path) }
        $replacements.Add($target.path,$bytes)
    }
    foreach($file in $mod.addFiles) {
        if(@($all | Where-Object Path -CEQ $file.path).Count) { throw 'The game already contains this mod. Select the original game folder.' }
        $bytes = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $file.file))
        if((Get-Sha256 $bytes) -ne $file.sha256) { throw 'An added mod file failed verification.' }
        $segments = $file.path.Split('/')
        $parent = $header
        for($index=0;$index -lt $segments.Length-1;$index++) {
            $parent = $parent.files.PSObject.Properties[$segments[$index]].Value
            if(-not $parent) { throw 'The game folder layout is unsupported.' }
        }
        $entry = [pscustomobject]@{size=$bytes.Length;offset='0';integrity=$null}
        $parent.files | Add-Member -MemberType NoteProperty -Name $segments[-1] -Value $entry
        [void]$all.Add([pscustomobject]@{Path=$file.path;Entry=$entry;OldOffset=[long]::MaxValue})
        $replacements.Add($file.path,$bytes)
    }
    if($CheckOnly) {
        [pscustomobject]@{Compatible=$true;Version=$mod.modVersion;VerifiedFiles=$replacements.Count;InstallationApproved=$mod.validation.installationApproved;OriginalGameUnchanged=$true}
        return
    }
    if($mod.validation.installationApproved -ne $true) { throw 'This candidate has not passed its full validation gates. Installation is disabled.' }
    if(Get-Process -Name Geoplanetical -ErrorAction SilentlyContinue) { throw 'Save and close the game before installing a separate edition.' }
    if(-not $Destination) { $Destination = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Geoplanetical-Month-Preparation' }
    $Destination = [IO.Path]::GetFullPath($Destination).TrimEnd('\','/')
    if($Destination.Equals($GameFolder,[StringComparison]::OrdinalIgnoreCase) -or $Destination.StartsWith($GameFolder+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or $GameFolder.StartsWith($Destination+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Choose a separate destination outside the original game folder.' }
    if((Test-Path -LiteralPath $Destination) -and @(Get-ChildItem -LiteralPath $Destination -Force).Count -gt 0) { throw 'The destination contains files. Choose a new empty folder.' }
    Write-Host 'Creating a separate edition from your own game. Please wait...'
    Copy-Runtime $GameFolder $Destination
    $packed = @($all | Where-Object {-not ($_.Entry.PSObject.Properties['unpacked'] -and $_.Entry.unpacked) -and -not $_.Entry.PSObject.Properties['link']} | Sort-Object OldOffset)
    $offset = [long]0
    foreach($item in $packed) {
        $item.Entry.offset = $offset.ToString([Globalization.CultureInfo]::InvariantCulture)
        if($replacements.ContainsKey($item.Path)) { Set-Integrity $item.Entry $replacements[$item.Path] }
        $offset += [long]$item.Entry.size
    }
    $newJson = $utf8.GetBytes(($header | ConvertTo-Json -Depth 100 -Compress))
    $headerLength = 8 + [int]([Math]::Ceiling($newJson.Length/4.0)*4)
    $newHeader = New-Object byte[] $headerLength
    [BitConverter]::GetBytes([uint32]($headerLength-4)).CopyTo($newHeader,0)
    [BitConverter]::GetBytes([uint32]$newJson.Length).CopyTo($newHeader,4)
    $newJson.CopyTo($newHeader,8)
    $sizeHeader = New-Object byte[] 8
    [BitConverter]::GetBytes([uint32]4).CopyTo($sizeHeader,0)
    [BitConverter]::GetBytes([uint32]$headerLength).CopyTo($sizeHeader,4)
    $destinationArchive = Join-Path $Destination 'resources\app.asar'
    $temp = $destinationArchive + '.building'
    $output = [IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try {
        $output.Write($sizeHeader,0,$sizeHeader.Length)
        $output.Write($newHeader,0,$newHeader.Length)
        $buffer = New-Object byte[] (8*1024*1024)
        foreach($item in $packed) {
            if($replacements.ContainsKey($item.Path)) { $bytes=$replacements[$item.Path];$output.Write($bytes,0,$bytes.Length) }
            else {
                [void]$source.Seek(($oldDataOffset+$item.OldOffset),[IO.SeekOrigin]::Begin)
                $remaining = [long]$item.Entry.size
                while($remaining -gt 0) {
                    $count = [int][Math]::Min([long]$buffer.Length,$remaining)
                    Read-Exactly $source $buffer $count
                    $output.Write($buffer,0,$count)
                    $remaining -= $count
                }
            }
        }
        $output.Flush($true)
    } finally { $output.Dispose() }
    [IO.File]::Move($temp,$destinationArchive)
    $exeBytes = [IO.File]::ReadAllBytes($sourceExe)
    $exeText = [Text.Encoding]::ASCII.GetString($exeBytes)
    $at = $exeText.IndexOf($oldHeaderHash,[StringComparison]::Ordinal)
    if($at -lt 0 -or $at -ne $exeText.LastIndexOf($oldHeaderHash,[StringComparison]::Ordinal)) { throw 'The copied package record is unsupported.' }
    $newHeaderHash = Get-Sha256 $newJson
    [Text.Encoding]::ASCII.GetBytes($newHeaderHash).CopyTo($exeBytes,$at)
    [IO.File]::WriteAllBytes((Join-Path $Destination 'Geoplanetical.exe'),$exeBytes)
    $installed = [pscustomobject]@{Mod=$mod.name;Version=$mod.modVersion;Source=$GameFolder;Destination=$Destination;HeaderSha256=$newHeaderHash;VerifiedTargets=$mod.targets;CreatedAt=[DateTime]::UtcNow.ToString('o')}
    [IO.File]::WriteAllText((Join-Path $Destination 'Month-preparation-mod.json'),($installed|ConvertTo-Json -Depth 20),$utf8)
    [IO.File]::Copy((Join-Path $PSScriptRoot 'README.txt'),(Join-Path $Destination 'README-Month-Preparation.txt'),$false)
    if(-not $NoShortcut) {
        $shortcutPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Geoplanetical Month Preparation.lnk'
        if(-not (Test-Path -LiteralPath $shortcutPath)) {
            $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut($shortcutPath)
            $shortcut.TargetPath = Join-Path $Destination 'Geoplanetical.exe'
            $shortcut.WorkingDirectory = $Destination
            $shortcut.IconLocation = $shortcut.TargetPath+',0'
            $shortcut.Description = 'Lightweight strategy graphics and background month preparation'
            $shortcut.Save()
        }
    }
    Write-Host ('Ready. Play from: '+$Destination)
    $installed | Select-Object Mod,Version,Destination
} finally { $source.Dispose() }
