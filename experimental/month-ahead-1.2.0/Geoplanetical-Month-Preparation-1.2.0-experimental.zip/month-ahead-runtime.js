/* Uninstalled full-world lookahead runtime. All numerical steps use the original engine. */
(function(root){
 'use strict';
 function makeRuntime(host,engine){
  const s={role:'authority',targetDay:null,gate:null,events:[],prefix:null,witnessDepth:0};
  const originalEmit=host.emit.bind(host),originalImmediate=host.emitImmediate.bind(host);
  function eventDay(){return host.sim?._dayJob?.target??host.sim?.day??-1;}
  function record(id,payload,immediate){
   if(s.role!=='shadow')return (immediate?originalImmediate:originalEmit)(id,payload);
   // Earlier predicted days will already have been shown by the real world.
   if(eventDay()===s.targetDay){if(s.events.length>=10000)throw Error('lookahead:event-limit');s.events.push({eventId:id,payload:structuredClone(payload)});}
  }
  host.emit=(id,payload)=>record(id,payload,false);
  host.emitImmediate=(id,payload)=>record(id,payload,true);
  if(typeof host.drainHostEvents==='function'){
   const drain=host.drainHostEvents.bind(host);
   host.drainHostEvents=()=>{const events=drain();if(s.role!=='shadow')return events;for(const e of events)record(e.eventId,e.payload,false);return [];};
  }
  const stable=()=>{const sim=host.requireHealthySession();if(sim._dayJob)throw Error('lookahead:uncommitted-day');if(engine.pendingTransport?.(sim))throw Error('lookahead:uncommitted-transport');return sim;};
  function facts(){
   const a=host.requireHealthySession();let next=a.day+1;
   for(let i=0;i<33;i++,next++)if(engine.monthDue(next))break;
   return {day:a.day,date:a.date.toISOString().slice(0,10),nextMonthDay:next,pending:!!a._dayJob,transportPending:!!engine.pendingTransport?.(a),jobTargetDay:a._dayJob?.target??null,blocked:engine.blocked(a),outcomeActive:engine.active(a),role:s.role,targetDay:s.targetDay,clock:{speedIdx:a.speedIdx,acc:a._acc||0,playtimeSec:a._playtimeSec||0},gate:s.gate?{...s.gate}:null};
  }
  function asPayload(capture){
   return {formatVersion:3,meta:capture.meta,parts:capture.artifact.parts.map(p=>({id:p.id,compression:p.source==='raw'?'identity':p.compression,rawBytes:p.source==='raw'?p.bytes.byteLength:p.rawBytes,bytes:p.bytes}))};
  }
  function snapshotCore(core){
   if(!s.witnessDepth)return core;
   if(!core?.sim)throw Error('lookahead:core-shape');
   // FfA receives a detached save manifest. Copying these two shallow objects
   // keeps both the live simulation and ordinary save/export data unchanged.
   const canonical={...core,sim:{...core.sim}};
   delete canonical.sim._acc;delete canonical.sim.speedIdx;delete canonical.sim._playtimeSec;
   return canonical;
  }
  async function capture(canonical=false,raw=true){
   stable();if(canonical)s.witnessDepth++;
   try{const value=raw&&engine.captureRaw?await engine.captureRaw(host):await host.saveSnapshot();stable();return value;}
   finally{if(canonical)s.witnessDepth--;}
  }
  async function witness(options={}){
   const raw=options.format!=='encoded'&&!!engine.captureRaw;
   const sim=stable(),day=sim.day,canonical=engine.canonicalSnapshotHook===true,c=await capture(canonical,raw),payload=asPayload(c),parts=[];
   for(const p of payload.parts){
    let bytes=p.bytes,compression=p.compression,rawBytes=p.rawBytes;
    if(p.id==='core'){
     if(!canonical){
      // The original baseline has no serialization hook. Retain an exact
      // compatibility path for independent replay and older snapshot hosts.
      const core=JSON.parse(new TextDecoder().decode(await engine.decode(p)));
      if(!core.sim)throw Error('lookahead:core-shape');
      delete core.sim._acc;delete core.sim.speedIdx;delete core.sim._playtimeSec;
      bytes=new TextEncoder().encode(JSON.stringify(core));
     }else if(p.compression!=='identity')throw Error('lookahead:canonical-core-encoding');
     compression='identity';rawBytes=bytes.byteLength;
    }
    if(raw&&compression!=='identity'){bytes=await engine.decode(p);compression='identity';rawBytes=bytes.byteLength;}
    // Equal encoding, lengths and encoded bytes imply equal decoded content.
    // Different encodings conservatively refuse promotion; they cannot cause
    // an unequal financial or transport state to be accepted.
    parts.push({id:p.id,compression,rawBytes,bytes:bytes.byteLength,sha256:await engine.hash(bytes)});
   }
   parts.sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);
   if(stable().day!==day)throw Error('lookahead:witness-moved');
   return {format:raw?'raw-save-witness-v3':'encoded-save-witness-v2',day,parts};
  }
  function reset(){s.role='authority';s.targetDay=null;s.gate=null;s.events.length=0;s.prefix=null;}
  function holdBoundary(a){
   const g=s.gate;if(s.role!=='authority'||!g||a!==host.sim||a.day+1!==g.targetDay)return false;
   if(!g.hit){g.hit=true;originalImmediate('lookahead.boundary',{targetDay:g.targetDay,generation:g.generation});}
   return true;
  }
  function step(options={}){
   if(s.role!=='shadow')throw Error('lookahead:not-shadow');
   const a=host.requireHealthySession(),budget=Math.max(.1,Math.min(20,Number(options.budgetMs)||8)),start=engine.now();
   let steps=0,advanced=0,waiting=false;
   while(engine.now()-start<budget||steps===0){
    if(!a._dayJob){
     if(engine.pendingTransport?.(a))return {...facts(),ready:false,waiting:true,steps,advanced};
     if(a.day>=s.targetDay)return {...facts(),ready:true,steps,advanced};
     if(!engine.active(a)||engine.blocked(a).length)return {...facts(),ready:false,blocked:engine.blocked(a),steps,advanced};
     // Stop on the last committed day so the exact pre-rollover state can be
     // fingerprinted before the whole final day/monthly cycle is predicted.
     if(a.day===s.targetDay-1&&!s.prefix)return {...facts(),needsPrefix:true,steps,advanced};
     a._dayJob=engine.newDay(a);
    }
    const job=a._dayJob,accumulator=a._acc;let result;
    // The original live scheduler zeroes fractional time while numerical
    // phases run. Formation and air-mission calculations read that field.
    a._acc=0;try{result=engine.next(a,job);}finally{a._acc=accumulator;}steps++;
    if(result==='faulted')throw a._dayFault||job.fault||Error('lookahead:day-fault');
    if(result==='done'){
     a._dayJob=null;engine.publish(a);host.commit();host.flushDomainEvents();advanced++;
     // One committed day per RPC keeps events and cancellation boundaries
     // clear and prevents a fast worker racing far beyond a required decision.
     return {...facts(),ready:a.day>=s.targetDay&&!engine.pendingTransport?.(a),steps,advanced};
    }
    if(result==='waiting'){waiting=true;break;}
   }
   return {...facts(),ready:false,steps,advanced,waiting};
  }
  async function dispatch(command,p={}){
   switch(command){
    case 'lookahead.facts':return facts();
   case 'lookahead.pacedPulse':{
    const wall=engine.normalizeDt(p.dtSeconds),scale=Math.max(.05,Math.min(1,Number(p.scale)||1));
    const playtime=Math.max(0,Number(host.sim._playtimeSec)||0);
    const status=host.pulse({dtSeconds:wall*scale});
    host.sim._playtimeSec=playtime+wall;
    return {status,facts:facts()};
   }
    case 'lookahead.export':{
     const c=await capture(),payload=asPayload(c),rawBytes=payload.parts.reduce((n,p)=>n+p.rawBytes,0);
     if(rawBytes>(Number(p.maxRawBytes)||768*1024*1024))throw Error('lookahead:snapshot-budget');
     return engine.transfer({payload,rawBytes,facts:facts()},payload.parts.map(p=>p.bytes));
    }
    case 'lookahead.configureShadow':{
     const a=stable(),target=Number(p.targetDay);if(!Number.isInteger(target)||target<=a.day||target>a.day+33)throw Error('lookahead:target');
     s.role='shadow';s.targetDay=target;s.gate=null;s.events.length=0;s.prefix=null;host.viewSubscriptions.clear();host.viewCache.clear();return facts();
    }
    case 'lookahead.step':return step(p);
    case 'lookahead.witness':return witness(p);
    case 'lookahead.capturePrefix':{
     if(s.role!=='shadow'||stable().day!==s.targetDay-1)throw Error('lookahead:prefix-day');
     s.prefix=await witness();return s.prefix;
    }
    case 'lookahead.arm':{
     const a=stable();if(s.role!=='authority'||a.day+1!==Number(p.targetDay)||!p.generation)throw Error('lookahead:arm-day');
     s.gate={targetDay:Number(p.targetDay),generation:String(p.generation),hit:false};return facts();
    }
    case 'lookahead.release':s.gate=null;return facts();
    case 'lookahead.promote':{
     const a=stable();if(s.role!=='shadow'||a.day!==s.targetDay||!s.prefix)throw Error('lookahead:not-ready');
     if(Number(p.prefixDay)!==s.prefix.day)throw Error('lookahead:promotion-prefix');
     const clock=p.clock||{};
     if(!Number.isFinite(clock.speedIdx)||!Number.isFinite(clock.acc)||!Number.isFinite(clock.playtimeSec))throw Error('lookahead:clock');
     a.speedIdx=engine.active(a)&&!engine.blocked(a).length?Math.max(0,Math.min(3,Math.trunc(clock.speedIdx))):0;
     a._acc=engine.active(a)?Math.max(0,clock.acc-1):0;a._playtimeSec=Math.max(0,clock.playtimeSec);
     s.role='authority';s.gate=null;
     host.viewSubscriptions.clear();for(const v of p.subscriptions||[])host.viewSubscriptions.set(String(v.viewId),structuredClone(v.params||{}));
     a._pendingViewDelta=null;
     host.viewCache.clear();host.commitRevision=Math.max(host.commitRevision,Number(p.commitRevision)||0);host.commit();engine.publish(a);host.bindDomainEvents();
     // The coordinator changes worker ownership only after this RPC returns.
     // Returning events avoids losing them while this endpoint is still hidden.
     const events=s.events.splice(0);
     return {status:host.status(true),facts:facts(),events};
    }
    default:throw Error('lookahead:unknown-command');
   }
  }
  return {dispatch,facts,reset,holdBoundary,snapshotCore};
 }
 root.__makeGeoMonthAheadRuntime=makeRuntime;
 if(typeof module!=='undefined')module.exports={makeRuntime};
})(globalThis);
