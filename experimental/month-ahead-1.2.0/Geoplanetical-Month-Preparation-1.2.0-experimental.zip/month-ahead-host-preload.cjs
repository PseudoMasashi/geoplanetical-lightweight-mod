'use strict';
const {ipcRenderer,contextBridge}=require('electron');
ipcRenderer.on('month-ahead:port',(event,meta)=>{if(event.ports.length===1&&/^world-[a-z0-9-]+$/.test(meta?.id||''))window.postMessage({type:'geo.month.port',id:meta.id},'*',[event.ports[0]]);});
contextBridge.exposeInMainWorld('__geoWorldMemory',{reclaim:(id,phase,cycle=0)=>{if(/^world-[a-z0-9-]+$/.test(id||'')&&['restored','booted','snapshot','commit'].includes(phase)&&Number.isSafeInteger(cycle)&&cycle>=0)ipcRenderer.send('month-ahead:world-reclaim',{id,phase,cycle});}});
