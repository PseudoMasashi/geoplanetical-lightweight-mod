/* Private prototype entry point. Never install before full-world parity tests. */
importScripts('month-ahead-controller.js','month-ahead-remote.js');
(function(){
 'use strict';
 const VERSION=2;let virtualEpoch=0,eventSeq=0,revision=0,controller;
 function transfers(value){
  // Every result buffer has already left the numerical worker. Transfer that
  // owned result rather than cloning large view/save buffers in the UI bridge.
  const list=[],seen=new WeakSet();function visit(v){if(!v||typeof v!=='object'||seen.has(v))return;seen.add(v);if(v instanceof ArrayBuffer){list.push(v);return;}if(ArrayBuffer.isView(v)){visit(v.buffer);return;}if(v instanceof Map){for(const[k,x]of v){visit(k);visit(x);}return;}if(v instanceof Set){for(const x of v)visit(x);return;}for(const k of Object.keys(v))visit(v[k]);}visit(value);return list;
 }
 function statusMeta(value){return value&&typeof value==='object'?{...value,sessionEpoch:virtualEpoch,commitRevision:Math.max(revision,Number(value.commitRevision)||0)}:value;}
 function payloadMeta(value,kind){
  if(!value||typeof value!=='object')return value;
  if(['session.boot','session.ready','domain.call','clock.advanceDays'].includes(kind)&&value.status)return {...value,sessionEpoch:virtualEpoch,status:statusMeta(value.status)};
  if(['clock.pulse','clock.setSpeed'].includes(kind)&&Object.hasOwn(value,'ready'))return statusMeta(value);
  return value;
 }
 function emit(eventId,payload){postMessage({protocolVersion:VERSION,type:'event',sessionEpoch:virtualEpoch,commitRevision:revision,eventSeq:++eventSeq,eventId,payload});}
 class Endpoint{
  constructor(role){
   this.role=role;this.worker=GeoRemoteWorld.create(message=>emit('lookahead.transport',message));this.requests=new Map();this.sequence=0;this.epoch=0;this.dead=false;
   this.worker.onmessage=e=>{
    const m=e.data;if(m.protocolVersion!==VERSION){this.fail(Error('lookahead:worker-protocol'));return;}
    if(m.type==='response'){
     this.epoch=m.sessionEpoch||this.epoch;
     const p=this.requests.get(m.requestId);if(!p)return;this.requests.delete(m.requestId);clearTimeout(p.timer);
     m.ok?p.resolve(m.payload):p.reject(Object.assign(new Error(m.error?.message||'Simulation request failed'),m.error||{}));
    }else if(m.type==='event'&&controller?.authority===this){revision=Math.max(revision,m.commitRevision||0);emit(m.eventId,payloadMeta(m.payload,m.eventId));}
   };
   this.worker.onerror=e=>this.fail(Error(e.message||'lookahead:worker-error'));
   this.worker.onmessageerror=()=>this.fail(Error('lookahead:worker-message'));
  }
  fail(error){this.dead=true;for(const p of this.requests.values()){clearTimeout(p.timer);p.reject(error);}this.requests.clear();this.worker.terminate();}
  call(command,payload={},list=[]){
   if(this.dead)return Promise.reject(Error('lookahead:endpoint-closed'));
   const requestId=++this.sequence;
   return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{this.requests.delete(requestId);reject(Error('lookahead:request-timeout:'+command));},180000);
    this.requests.set(requestId,{resolve,reject,timer});
    try{this.worker.postMessage({protocolVersion:VERSION,type:'request',requestId,sessionEpoch:this.epoch,command,payload},[...new Set(list)]);}catch(e){clearTimeout(timer);this.requests.delete(requestId);reject(e);}
   });
  }
  async terminate(){if(this.dead)return;this.fail(Error('lookahead:cancelled'));}
 }
 controller=new GeoMonthAheadController({enabled:false,createEndpoint:role=>new Endpoint(role),onStatus:s=>emit('lookahead.status',s),onPromoteEvents:(events,nextRevision)=>{revision=Math.max(revision,nextRevision);for(const e of events)emit(e.eventId,payloadMeta(e.payload,e.eventId));}});
 let serial=Promise.resolve(),configurationSequence=0;
 onmessage=e=>{
  const m=e.data;
  if(m?.type==='geo.remote.port'){GeoRemoteWorld.connect(m.id,m.port);return;}
  if(m?.type==='geo.remote.failed'){GeoRemoteWorld.fail(m.id,m.message);return;}
  const configuration=m?.protocolVersion===VERSION&&m.type==='request'&&m.command==='lookahead.configure'?++configurationSequence:null;
  let interruption=null;
  // Memory guards must be able to discard an extra world during a long boot
  // or witness. Ordinary world commands stay ordered on the normal queue.
  if(configuration!==null&&m.payload?.enabled===false&&(!m.sessionEpoch||m.sessionEpoch===virtualEpoch)){
   controller.enabled=false;interruption=controller.cancel('preparation-disabled');interruption.catch(()=>{});
  }
  serial=serial.catch(()=>{}).then(async()=>{
   if(m?.protocolVersion!==VERSION||m.type!=='request')throw Error('lookahead:client-protocol');
   if(m.command==='session.boot')virtualEpoch++;
   try{
    if(m.command!=='session.boot'&&m.sessionEpoch&&m.sessionEpoch!==virtualEpoch)throw Error('lookahead:stale-client-session');
    let result;
    if(m.command==='lookahead.configure'){
     if(typeof m.payload?.enabled!=='boolean')throw Error('lookahead:enabled-boolean');
     if(m.payload.smoothCalendar!==undefined&&typeof m.payload.smoothCalendar!=='boolean')throw Error('lookahead:pacing-boolean');
     await interruption;
     if(configuration===configurationSequence){
      if(m.payload.smoothCalendar!==undefined)controller.smoothCalendar=m.payload.smoothCalendar;
      if(controller.enabled!==m.payload.enabled){controller.enabled=m.payload.enabled;if(!controller.enabled)await controller.cancel('preparation-disabled');else{controller.retryBlocked=false;controller.start();}}
     }
     controller.announce();result=controller.status();
    }else result=await controller.dispatch(m.command,m.payload||{});
    if(m.command==='session.shutdown')await controller.authority.terminate();
    revision=Math.max(revision,result?.status?.commitRevision||result?.commitRevision||0);
    postMessage({protocolVersion:VERSION,type:'response',requestId:m.requestId,sessionEpoch:virtualEpoch,commitRevision:revision,ok:true,payload:payloadMeta(result,m.command)},[...new Set(transfers(result))]);
   }catch(error){postMessage({protocolVersion:VERSION,type:'response',requestId:m.requestId,sessionEpoch:virtualEpoch,commitRevision:revision,ok:false,error:{name:error.name||'Error',message:String(error.message||error)}});}
  }).catch(error=>emit('lookahead.proxyError',{message:String(error.message||error)}));
 };
})();
