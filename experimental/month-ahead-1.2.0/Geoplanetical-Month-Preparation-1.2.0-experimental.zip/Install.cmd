@echo off
setlocal DisableDelayedExpansion
echo GEOPLANETICAL MONTH PREPARATION 1.2.0 - EXPERIMENTAL
echo This build has not passed full same-command year testing.
echo Your campaign may diverge from the original game's results.
echo Back up saves first. The original game files will be copied, not modified.
choice /C YN /N /M "Install this experimental build in a separate copy? [Y/N] "
if errorlevel 2 goto cancelled
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -AcceptExperimentalRisk
goto end
:cancelled
echo Cancelled. Nothing was installed.
:end
pause
