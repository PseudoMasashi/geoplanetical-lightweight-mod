'use strict';
const path=require('node:path'),os=require('node:os');
let compaction=null;
function compactMainProcess(){
 if(compaction)return compaction;
 compaction=(async()=>{const before=process.memoryUsage();let session;
  try{session=new(require('node:inspector').Session)();session.connect();await new Promise((resolve,reject)=>session.post('HeapProfiler.collectGarbage',{},e=>e?reject(e):resolve()));return {ok:true,before,after:process.memoryUsage()};}
  catch(e){return {ok:false,message:String(e.message||e),before,after:process.memoryUsage()};}
  finally{session?.disconnect();}
 })().finally(()=>{compaction=null;});return compaction;
}
function registerWorlds({ipcMain,BrowserWindow,MessageChannelMain,getOwner,rendererRoot,preload,allowOriginal=false,candidateFile='simulation-worker.bundle.js',onMemoryCompaction=()=>{}}){
 const worlds=new Map(),opening=new Map(),collectors=new Map();let watched=null;
 const ownerEvent=e=>{const owner=getOwner();return owner&&!owner.isDestroyed()&&e.sender===owner.webContents&&e.senderFrame===owner.webContents.mainFrame;};
 const fail=(id,message)=>{const owner=getOwner();if(owner&&!owner.isDestroyed())owner.webContents.send('month-ahead:world-failed',{id,message});};
 function close(id){opening.delete(id);collectors.delete(id);const w=worlds.get(id);if(!w)return;worlds.delete(id);if(!w.isDestroyed())w.destroy();}
 function clear(){opening.clear();for(const id of [...worlds.keys()])close(id);}
 ipcMain.on('month-ahead:world-open',async(event,request)=>{
  if(!ownerEvent(event))return;const {id,original=false}=request||{};
  if(!/^world-[a-z0-9-]+$/.test(id||'')||worlds.has(id)||opening.has(id)||worlds.size+opening.size>=2||original&&!allowOriginal){fail(id,'Background world request refused');return;}
  if(os.freemem()<1.25*1024**3){fail(id,'Not enough memory for background preparation');return;}
  const owner=getOwner();if(watched!==owner){watched=owner;owner.once('closed',clear);}
  // Large save and asset responses can leave disposable buffers awaiting GC in
  // the Electron main process. Reclaim only unreachable objects before adding
  // a second model; no campaign state or live cache is removed.
  const token={};opening.set(id,token);const reclaimed=await compactMainProcess();onMemoryCompaction({id,...reclaimed});
  if(opening.get(id)!==token||!ownerEvent(event))return;opening.delete(id);
  const win=new BrowserWindow({show:false,webPreferences:{preload,sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'month-ahead-'+id}});worlds.set(id,win);
  const sessions=new Set(),used=new Set(),queued=[];let collecting=false;
  collectors.set(id,async(phase,cycle=0)=>{
   const key=phase+':'+cycle;if(used.has(key)||win.isDestroyed())return;if(collecting){if(!queued.some(x=>x.phase===phase&&x.cycle===cycle))queued.push({phase,cycle});return;}used.add(key);collecting=true;
   try{for(const session of sessions){const before=await win.webContents.debugger.sendCommand('Runtime.getHeapUsage',{},session);const at=performance.now();await win.webContents.debugger.sendCommand('HeapProfiler.collectGarbage',{},session);const after=await win.webContents.debugger.sendCommand('Runtime.getHeapUsage',{},session);onMemoryCompaction({id,target:'numerical-worker',phase,ok:true,elapsedMs:performance.now()-at,before,after});}}
   catch(e){onMemoryCompaction({id,target:'numerical-worker',phase,ok:false,message:String(e.message||e)});}
   finally{collecting=false;const next=queued.shift();if(next)collectors.get(id)?.(next.phase,next.cycle);}
  });
  try{const debug=win.webContents.debugger;debug.attach('1.3');debug.on('message',(_,method,params)=>{if(method==='Target.attachedToTarget'&&params.targetInfo?.type==='worker')sessions.add(params.sessionId);if(method==='Target.detachedFromTarget')sessions.delete(params.sessionId);});debug.sendCommand('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:false,flatten:true}).catch(()=>{});}catch{}
  win.webContents.once('did-finish-load',()=>{
   if(worlds.get(id)!==win||owner.isDestroyed()){close(id);return;}
   const {port1,port2}=new MessageChannelMain();
   owner.webContents.postMessage('month-ahead:port',{id},[port1]);win.webContents.postMessage('month-ahead:port',{id},[port2]);
  });
  win.webContents.on('render-process-gone',(_,details)=>{close(id);fail(id,'Background world stopped: '+details.reason+' ('+details.exitCode+')');});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.on('will-navigate',event=>event.preventDefault());
  win.loadFile(path.join(rendererRoot,'month-ahead-host.html'),{query:{id,worker:original?'simulation-worker.original.bundle.js':candidateFile}}).catch(e=>{close(id);fail(id,e.message);});
 });
 ipcMain.on('month-ahead:world-reclaim',(event,request)=>{const {id,phase,cycle=0}=request||{},win=worlds.get(id);if(!win||win.isDestroyed()||event.sender!==win.webContents||event.senderFrame!==win.webContents.mainFrame||!['restored','booted','snapshot','commit'].includes(phase)||!Number.isSafeInteger(cycle)||cycle<0)return;collectors.get(id)?.(phase,cycle);});
 ipcMain.on('month-ahead:world-close',(event,request)=>{if(ownerEvent(event)&&typeof request?.id==='string')close(request.id);});
 return {closeAll:clear,size:()=>worlds.size};
}
module.exports={registerWorlds};
