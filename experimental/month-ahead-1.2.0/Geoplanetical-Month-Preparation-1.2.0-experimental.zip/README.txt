GEOPLANETICAL MONTH PREPARATION 1.2.0 - EXPERIMENTAL OPT-IN

This is an unverified early-access build. Read VALIDATION.txt before installing. The full same-command year comparison has not passed; one four-month native run refused promotion and ended differently from its reference. The research choices in that run may not have matched. Your campaign may diverge from the original game. A better verified version is still the goal.

To try it, extract the entire package, back up your saves, then run Install.cmd and accept its warning. It creates a separate game copy from your own supported original installation and checks exact source hashes. Allow about 4 GB of additional disk space. No game binaries, assets, saves or personal settings are included in this package.

The original installation files are preserved. Both copies use the same normal game profile and saves; close one before opening the other. Back up saves before trying the experimental calculation path.

This is not a Mod Studio or Steam Workshop pack. Mod Studio supports presentation data, not this executable simulation adapter. The candidate caps rendering at 30 FPS or lower, prepares the full monthly calculation in a separate world, cancels preparation when player changes invalidate it, and checks the result before promotion. It uses extra CPU and RAM. Some waits remain possible, and a faster month-end is not guaranteed by the incomplete comparison.

Use this version only if you accept those limits. To cancel, choose N at the installer prompt. You can continue to launch the untouched original game.
