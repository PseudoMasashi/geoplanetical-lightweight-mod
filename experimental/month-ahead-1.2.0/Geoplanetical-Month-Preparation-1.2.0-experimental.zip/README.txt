GEOPLANETICAL MONTH PREPARATION 1.2.0 - EXPERIMENTAL

Read VALIDATION.txt first. This is a source-only candidate preserved for later work, not a ready-to-play release. Installation is deliberately disabled until the full same-input comparison passes. It cannot run through Mod Studio or Steam Workshop.

The separate-copy installer is included for the eventual verified release. Each player must supply their own exact supported game build. No game binaries, assets, saves or personal settings are included.

Original numerical formulas and phase order are retained. A separate world prepares the full monthly calculation, rendering is capped at 30 FPS, player changes invalidate preparation, and an exact pre-boundary check controls promotion. Preparation uses additional CPU/RAM. Normal fallback remains available.

Unzip the entire package. Do not modify the approval flag to bypass validation. This handoff has not been installed or published as a playable update.
