/* Native message ports keep each complete world in its own renderer process. */
(function(root){
 'use strict';
 const worlds=new Map();let sequence=0;
 class RemoteWorldWorker{
  constructor(control,original=false){this.id='world-'+Date.now().toString(36)+'-'+(++sequence);this.control=control;this.port=null;this.queue=[];this.dead=false;worlds.set(this.id,this);control({type:'geo.remote.open',id:this.id,original:!!original});}
  postMessage(message,transfers=[]){if(this.dead)throw Error('lookahead:remote-world-closed');if(this.port)this.port.postMessage(message,transfers);else this.queue.push({message,transfers});}
  connect(port){if(this.dead){port.close();return;}if(this.port)throw Error('lookahead:duplicate-world-port');this.port=port;port.onmessage=e=>this.onmessage?.(e);port.onmessageerror=e=>this.onmessageerror?.(e);port.start?.();for(const item of this.queue.splice(0))port.postMessage(item.message,item.transfers);}
  fail(message){if(this.dead)return;this.onerror?.({message:String(message)});}
  terminate(){if(this.dead)return;this.dead=true;worlds.delete(this.id);this.queue.length=0;this.port?.close();this.control({type:'geo.remote.close',id:this.id});}
 }
 const api={create:(control,original)=>new RemoteWorldWorker(control,original),connect:(id,port)=>{const w=worlds.get(id);if(w)w.connect(port);else port.close();},fail:(id,message)=>worlds.get(id)?.fail(message)};
 root.GeoRemoteWorld=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
